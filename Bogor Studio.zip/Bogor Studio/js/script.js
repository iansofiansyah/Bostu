$(document).ready(function(){
    $(".toggle").click(function(){
        $("nav").toggle();
    });
});


/* view info profile */
$(document).ready(function(){
    $('.webprog').show();
    $('.netprog').hide();
    


$("#weblink").click(function () {
    $('.netprog').hide();
    $('#netlink').removeClass("active");
    $('.webprog').show();
    $("#weblink").addClass("active");
    
});

$("#netlink").click(function () {
    $('.webprog').hide();
    $('#weblink').removeClass("active");
    $('.netprog').show();
    $("#netlink").addClass("active");
});
});